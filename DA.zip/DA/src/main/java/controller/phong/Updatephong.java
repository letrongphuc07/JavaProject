package controller.phong;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.LoaiPhongDao;
import database.PhongDao;
import model.LoaiPhong;
import model.Phong;

/**
 * Servlet implementation class Updatephong
 */
@WebServlet("/updatephong")
public class Updatephong extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updatephong() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String maphong = request.getParameter("maphong");
		PhongDao dao = new PhongDao();
		Phong p = dao.getPhongByMa(maphong);
		request.setAttribute("pP", p);
		request.setAttribute("listlp", p.getLoaiphong().getMaloaiphong());
		
		LoaiPhongDao dao1 = new LoaiPhongDao();
		List<LoaiPhong> list1 = dao1.getAllLoaiPhong();
		request.setAttribute("loaiphonglist", list1);
		
		request.getRequestDispatcher("phong/update.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		
		String maphong = request.getParameter("maphong");
		String tenphong = request.getParameter("tenphong");
		String loaiphong = request.getParameter("loaiphong");
		String trangthai = request.getParameter("trangthai");
		
		PhongDao dao = new PhongDao();
		Phong p = new Phong(maphong, tenphong, new LoaiPhong(loaiphong), trangthai);
		dao.updatePhong(p);
		response.sendRedirect("showphong");
	}

}
