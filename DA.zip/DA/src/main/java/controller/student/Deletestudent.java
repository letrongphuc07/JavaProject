package controller.student;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.StudentDao;
import model.Student;

/**
 * Servlet implementation class Deletestudent
 */
@WebServlet("/deletestudent")
public class Deletestudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Deletestudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String masv = request.getParameter("masv");
		StudentDao dao = new StudentDao();
		Student st = dao.getStudentByMa(masv);
		request.setAttribute("stT", st);
		request.getRequestDispatcher("/student/delete.jsp").forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String masv = request.getParameter("masv");
		System.out.println(masv);
		StudentDao dao = new StudentDao();
		dao.deleteStudent(masv);
		response.sendRedirect("showstudent");
	}

}
