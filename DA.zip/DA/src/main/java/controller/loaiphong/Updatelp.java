package controller.loaiphong;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import database.LoaiPhongDao;
import model.LoaiPhong;

/**
 * Servlet implementation class Updatelp
 */
@WebServlet("/updatelp")
public class Updatelp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Updatelp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String maloaiphong = request.getParameter("maloaiphong");
		LoaiPhongDao dao = new LoaiPhongDao();
		LoaiPhong lp = dao.getLoaiPhongByMa(maloaiphong);
		request.setAttribute("lpP", lp);
		request.getRequestDispatcher("/loaiphong/update.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String maloaiphong = request.getParameter("maloaiphong");
		String tenloaiphong = request.getParameter("tenloaiphong");
		String dongia_Str = request.getParameter("dongia");
		
		int dongia;
		try {
			dongia = Integer.parseInt(dongia_Str);
		} catch (NumberFormatException e) {
			dongia = 0;
			e.printStackTrace();
		}
		
		
		LoaiPhongDao dao = new LoaiPhongDao();
		dao.updateLoaiPhong(maloaiphong, tenloaiphong, dongia);
		response.sendRedirect("showlp");
	}

}
