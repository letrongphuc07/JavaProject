package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import model.Student;

public class StudentDao {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public List<Student> getAllStudent() {
		List<Student> list = new ArrayList<>();
		String query = "SELECT * FROM student";
		try {
			conn = new JDBCUtil().getConnection();
			ps = conn.prepareStatement(query);
			rs = ps.executeQuery();

			while (rs.next()) {
				list.add(new Student(rs.getString(1)
						, rs.getString(2)
						, rs.getDate(3)
						, rs.getString(4)
						, rs.getString(5)
						, rs.getString(6)));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	public void insertStudent(String masv, String hoten, Date ngaysinh, String gioitinh, String diachi, String sodienthoai) {
		String query = "INSERT INTO student\r\n" + "VALUES (?,?,?,?,?,?)";

		try {
			conn = new JDBCUtil().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, masv);
			ps.setString(2, hoten);
			ps.setDate(3, ngaysinh);
			ps.setString(4, gioitinh);
			ps.setString(5, diachi);
			ps.setString(6, sodienthoai);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public Student getStudentByMa(String masv) {
		String query = "SELECT * FROM student\r\n"
				+ "WHERE masv = ?";
		try {
			conn = new JDBCUtil().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, masv);
			rs = ps.executeQuery();
			while(rs.next()) {
				return new Student(rs.getString(1)
						, rs.getString(2)
						, rs.getDate(3)
						, rs.getString(4)
						, rs.getString(5)
						, rs.getString(6));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateStudent(String masv, String hoten, String ngaysinh, String gioitinh, String diachi, String sodienthoai ) {
		String query = "UPDATE student\r\n"
				+ "SET hoten = ?, ngaysinh = ?, gioitinh = ?, diachi = ?, sodienthoai=?\r\n"
				+ "WHERE masv = ?";
		try {
			conn = JDBCUtil.getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, hoten);
			/*
			 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); Date date = (Date)
			 * sdf.parse(ngaysinh);
			 */
			ps.setString(2, ngaysinh);
			ps.setString(3, gioitinh);
			ps.setString(4, diachi);
			ps.setString(5, sodienthoai);
			ps.setString(6, masv);
			System.out.println(gioitinh);
			System.out.println(ps.executeUpdate());;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void deleteStudent(String masv) {
		String query = "DELETE FROM student\r\n"
				+ "WHERE masv = ?";
		try {
			conn = JDBCUtil.getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, masv);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
